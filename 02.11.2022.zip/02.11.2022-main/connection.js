let mysql = require('mysql');   //mysql mödülünü import ettik
const ayar = require('./dbConfig.js');  //ayardosyamızı import ettik

module.exports = class _mysql{
    
    constructor(){

        this.connection = mysql.createConnection(ayar.mysqlParams);     //ayar dosyamızdan db verilerini çektik
        
    }

    baglan(){

        this.connection.connect();      //db ye bağlandık

    }

    veriGir(id,veri){      //verigirişi yapmak için fonksiyon yazdık

        this.connection.query(`insert into veriler (id,bilgi) values (${id},"${veri}")`, function (error, results, fields) {    //sorguları db ye gönderdik

            if (error) throw error;

            console.log('veriler eklendi');     
        });
    }

    kapat(){

        this.connection.end();      //bağlantıyı kapatan fondksiyon

    }
   
}