let ayar = require('./dbConfig');
let netw = require("net");

class network{
    
    constructor(){

    }
    
    networkDuzenle(){
    
        this.net=netw.createServer((socket)=>{

            console.log("Bağlantı gerçekleşti");

            socket.on("data",(veri)=>{
    
                console.log(veri.toString());
    
            })
    
        });
        
        this.net.listen(ayar.networkPort);
    
    }

}

module.exports=network;