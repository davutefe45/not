module.exports = {
    mysqlParams:{
    host : 'localhost',         //db için parametreler
    user : 'hamza',
    password : '123',
    database : 'verilerdb',
    },

    networkPort:4356,       //ağ için parametreler
    
}