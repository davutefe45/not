let dbconn = require('./connection');       

let mysqlconn = new dbconn();       //connection modülü için nesne oluşturuyoruz


mysqlconn.baglan();     //oluşturduğumuz nesnenin içinden bağlan fonk çağırıyoruz
mysqlconn.veriGir(123456,'asdsdasdasasasd');        //veri girişi fonk çağırıyoruz
mysqlconn.kapat();      //db kapatma fonk çağırıyoruz