let config=require("./config.js");
let mysqldb=require("./db");
let netw=require("net");

class network{
    constructor(){
        this.mydb=new mysqldb();

    }
    networkDuzenle(){
        let self=this;
        this.net = netw.createServer((socket)=>{
            console.log("Bağlandı");

            socket.on("data",(veri)=>{
                let veri2=veri.toString();
                console.log(veri2);
                try
                {
                    let sayi=JSON.parse(veri2);
                    if(sayi.id != undefined)
                    {
                        self.mydb.veriekle(sayi.id,veri2);
                    }
                    else
                    {
                        console.log("ID Bulunamadı");

                    }
                }
                catch
                {
                    console.log("Hatalı Veri")
                }
                
                
                

            })
            

           
        });

        this.net.listen(config.networkPort);
    }

}
module.exports=network;
    

