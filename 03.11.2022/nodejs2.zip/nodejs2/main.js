
let netw=require("./network");


let netww=new netw();
netww.networkDuzenle();

//mydb.veriekle(12345,'{"adi":"eshabil"}');
