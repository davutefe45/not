let ayar=require("./config.js");
let mysql=require("mysql")

class mysqldb{
    constructor(){

        this.mydb= mysql.createConnection(ayar.mysqlParams)
        this.mydb.connect();
            
    }
    disconnect(){
        this.mydb.end();
    } 
    veriekle(id,veri){

        this.mydb.query(`INSERT INTO veriler (id,veri) VALUES(${id},'${veri}')`,
            function (error, results, fields){
                if (error) throw error;
            });
    }
   
    
}
module.exports=mysqldb;
        
        