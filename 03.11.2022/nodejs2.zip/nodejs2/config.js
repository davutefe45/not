module.exports = {
  
    mysqlParams: {
        host     : 'localhost',
        user     : 'eshabil',
        password : '123456',
        database : 'verilerdb'
    },

    networkPort: 4356
//ıp : 155.223.245.164
};